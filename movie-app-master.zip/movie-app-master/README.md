# Movie-app

### [LINK](bilimovies.netlify.app)

## Resource
#### Google font: https://fonts.google.com/

#### Icon: https://www.flaticon.com/

#### API: https://www.themoviedb.org/   ,  https://www.2embed.ru/
## Project Using
#### Slick
#### TailwindCSS
#### Axios
## Preview

![image1](https://user-images.githubusercontent.com/62241342/146627330-ab495599-b2ba-4471-9c38-1f80b85adf3a.png)



![image2](https://user-images.githubusercontent.com/62241342/146627335-2f09db17-d7b5-402e-8c55-1ac2763ab62f.png)



![image3](https://user-images.githubusercontent.com/62241342/146627339-8e2f0ec1-b4c5-4454-a818-9b9e28ce942f.png)
