import Menu from "./../Menu/Menu";

function MovieInfor() {
  return <div className=" w-full bg-transparent py-4  text-white ">
      
  </div>;
}
export default MovieInfor;
